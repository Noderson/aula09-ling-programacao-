#include <stdio.h>

int totalVendas = 0;
float valorTotalVendido = 0.0;

// Funções do sistema
float calcularDesconto(float valorCompra) {
    if(valorCompra < 100) return 0;
    else if(valorCompra < 500) return 5;
    else if(valorCompra < 1000) return 10;
    else return 15;
}

float aplicarDesconto(float valor, float percentual) {
    return valor - (valor * percentual / 100);
}

float calcularValorFinal(float valor) {
    float desconto = calcularDesconto(valor);
    return aplicarDesconto(valor, desconto);
}

void exibirResumo(float valorOriginal, float percentualDesconto, float valorDesconto, float valorFinal) {
    printf("\n=== Resumo da Compra ===\n");
    printf("Valor Original: R$ %.2f\n", valorOriginal);
    printf("Percentual de Desconto: %.0f%%\n", percentualDesconto);
    printf("Valor do Desconto: R$ %.2f\n", valorDesconto);
    printf("Valor Final: R$ %.2f\n", valorFinal);
}

int main() {
    float valorCompra, desconto, valorFinal, valorDesconto;
    char continuar;

    do {
        printf("\n=== desconto_progressivo === \n");
        printf("\nDigite o valor da compra: R$ ");
        scanf("%f", &valorCompra);

        desconto = calcularDesconto(valorCompra);
        valorFinal = aplicarDesconto(valorCompra, desconto);
        valorDesconto = valorCompra - valorFinal;

        exibirResumo(valorCompra, desconto, valorDesconto, valorFinal);

        totalVendas++;
        valorTotalVendido += valorFinal;

        printf("\nDeseja registrar outra venda? (s/n): ");
        scanf(" %c", &continuar);
    } while(continuar == 's' || continuar == 'S');

    printf("\nTotal de vendas realizadas: %d\n", totalVendas);
    printf("Valor total vendido: R$ %.2f\n", valorTotalVendido);

    return 0;
}
