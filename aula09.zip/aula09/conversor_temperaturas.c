#include <stdio.h>

// Funções de conversão
float celsiusParaFahrenheit(float celsius) {
    return celsius * 9/5 + 32;
}

float fahrenheitParaCelsius(float fahrenheit) {
    return (fahrenheit - 32) * 5/9;
}

float celsiusParaKelvin(float celsius) {
    return celsius + 273.15;
}

float kelvinParaCelsius(float kelvin) {
    return kelvin - 273.15;
}

float fahrenheitParaKelvin(float fahrenheit) {
    return celsiusParaKelvin(fahrenheitParaCelsius(fahrenheit));
}

float kelvinParaFahrenheit(float kelvin) {
    return celsiusParaFahrenheit(kelvinParaCelsius(kelvin));
}

int main() {
    int opcao;
    float valor, resultado;

    do {
        printf("\n=== Conversor de Temperaturas ===\n");
        printf("1. Celsius para Fahrenheit\n");
        printf("2. Fahrenheit para Celsius\n");
        printf("3. Celsius para Kelvin\n");
        printf("4. Kelvin para Celsius\n");
        printf("5. Fahrenheit para Kelvin\n");
        printf("6. Kelvin para Fahrenheit\n");
        printf("0. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao >= 1 && opcao <= 6) {
            printf("Digite o valor da temperatura: ");
            scanf("%f", &valor);
        }

        switch(opcao) {
            case 1:
                resultado = celsiusParaFahrenheit(valor);
                printf("%.2f Celsius = %.2f Fahrenheit\n", valor, resultado);
                break;
            case 2:
                resultado = fahrenheitParaCelsius(valor);
                printf("%.2f Fahrenheit = %.2f Celsius\n", valor, resultado);
                break;
            case 3:
                resultado = celsiusParaKelvin(valor);
                printf("%.2f Celsius = %.2f Kelvin\n", valor, resultado);
                break;
            case 4:
                resultado = kelvinParaCelsius(valor);
                printf("%.2f Kelvin = %.2f Celsius\n", valor, resultado);
                break;
            case 5:
                resultado = fahrenheitParaKelvin(valor);
                printf("%.2f Fahrenheit = %.2f Kelvin\n", valor, resultado);
                break;
            case 6:
                resultado = kelvinParaFahrenheit(valor);
                printf("%.2f Kelvin = %.2f Fahrenheit\n", valor, resultado);
                break;
            case 0:
                printf("Saindo...\n");
                continue;
            default:
                printf("Opcao invalida!\n");
                continue;
        }

    } while(opcao != 0);

    return 0;
}
