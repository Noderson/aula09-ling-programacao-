#include <stdio.h>

// Funções do IMC
float calcularIMC(float peso, float altura) {
    return peso / (altura * altura);
}

void exibirClassificacao(float imc) {
    if(imc < 18.5) printf("Abaixo do peso\n");
    else if(imc < 25.0) printf("Peso normal\n");
    else if(imc < 30.0) printf("Sobrepeso\n");
    else if(imc < 35.0) printf("Obesidade Grau I\n");
    else if(imc < 40.0) printf("Obesidade Grau II\n");
    else printf("Obesidade Grau III\n");
}

int validarDados(float peso, float altura) {
    return (peso > 0 && altura > 0) ? 1 : 0;
}

float calcularPesoIdeal(float altura) {
    return 22 * (altura * altura);
}

int main() {
    float peso, altura, imc;

    printf("\n=== CALCULADORA IMC  ===\n");
    printf("Digite seu peso (kg): ");
    scanf("%f", &peso);
    printf("Digite sua altura (m): ");
    scanf("%f", &altura);

    if(!validarDados(peso, altura)) {
        printf("Dados invalidos!\n");
        return 1;
    }

    imc = calcularIMC(peso, altura);
    printf("Seu IMC: %.2f\n", imc);
    exibirClassificacao(imc);
    printf("Peso ideal aproximado: %.2f kg\n", calcularPesoIdeal(altura));

    return 0;
}
